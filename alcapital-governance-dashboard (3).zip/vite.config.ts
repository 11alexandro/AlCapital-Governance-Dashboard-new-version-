import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR toggles via the DISABLE_HMR environment variable.
      hmr: process.env.DISABLE_HMR !== 'true',
      // File watching is deactivated in specific environments to conserve CPU during code updates.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
